/* package.js
 * license: NCSA
 * copyright: Jordipujol @ Senko's Pub
 * website: https://www.guilded.gg/senkospub
 * authors:
 * Jordipujol
 */

const { Mod } = require("./src/mod.js");

module.exports.mod = new Mod();
