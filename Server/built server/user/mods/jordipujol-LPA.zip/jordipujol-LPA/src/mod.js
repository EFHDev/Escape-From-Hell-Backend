/* mod.js
 * license: NCSA
 * copyright: Senko's Pub
 * website: https://www.guilded.gg/senkospub
 * authors:
 * Jordipujol
 */

"use strict";

class Mod
{
    constructor()
    {
        this.mod = "jordipujol-LPA";
        this.funcptr = https_f.server.onRespond["IMAGE"];

        common_f.logger.logInfo(`Loading: ${this.mod}`);
        core_f.packager.onLoad[this.mod] = this.load.bind(this);        
        https_f.server.onRespond["IMAGE"] = this.getImage.bind(this);
    }

    getImage(sessionID, req, resp, body)
    {
        const filepath = `${core_f.packager.getModPath(this.mod)}res/`;

        if (req.url.includes("/avatar/LPA"))
        {
            https_f.server.sendFile(resp, `${filepath}LPA.jpg`);
            return;
        }

        this.funcptr(sessionID, req, resp, body);
    }

    load()
    {
        const filepath = `${core_f.packager.getModPath(this.mod)}db/`;
        database_f.server.tables.traders.LPA = {
            "assort":       common_f.json.deserialize(common_f.vfs.readFile(`${filepath}assort.json`)),
            "base":         common_f.json.deserialize(common_f.vfs.readFile(`${filepath}base.json`)),
            "dialogue":     common_f.json.deserialize(common_f.vfs.readFile(`${filepath}dialogue.json`)),
            "questassort":  common_f.json.deserialize(common_f.vfs.readFile(`${filepath}questassort.json`)),
            "suits":        common_f.json.deserialize(common_f.vfs.readFile(`${filepath}suits.json`))
        };
        let locales = database_f.server.tables.locales.global;

        for (const locale in locales)
        {
            locales[locale].trading.LPA = {
                "FullName": "Lock-Picking Attorney",
                "FirstName": "Lockpick",
                "Nickname": "Lock-Picking Attorney",
                "Location": "Unknown",
                "Description": "He's climbin' in yo windows, snatching yo people up."
            };
        }

        database_f.server.tables.locales.global = locales;
    }
}

module.exports.Mod = Mod;
